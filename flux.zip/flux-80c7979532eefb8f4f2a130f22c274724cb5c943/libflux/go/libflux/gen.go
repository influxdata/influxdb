package libflux

//go:generate go run ./internal/buildinfo
