### Creating Release tag
We are using semantic versioning with the format "vMajor.Minor.Patch"

```sh
git tag -s v0.0.1
make release
```

