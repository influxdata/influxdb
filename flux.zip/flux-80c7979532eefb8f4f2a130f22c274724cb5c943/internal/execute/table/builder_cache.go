package table

import (
	"github.com/influxdata/flux/execute/table"
)

type (
	Builder      = table.Builder
	BuilderCache = table.BuilderCache
)
