fn main() -> anyhow::Result<(), anyhow::Error> {
    caller::possible_main()?;
    Ok(())
}
