// Package executetest contains utilities for testing the query execution phase.
package executetest
