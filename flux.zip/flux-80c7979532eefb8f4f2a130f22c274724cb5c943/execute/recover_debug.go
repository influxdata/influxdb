//go:build debug
// +build debug

package execute

func (es *executionState) recover() {}
func (d *poolDispatcher) recover()  {}
