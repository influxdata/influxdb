// Package mock contains mock implementations of the query package interfaces for testing.
package mock
