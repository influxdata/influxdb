package fbsemantic

//go:generate flatc --go  --gen-onefile --go-namespace fbsemantic ./semantic.fbs
//go:generate go fmt ./semantic_generated.go
