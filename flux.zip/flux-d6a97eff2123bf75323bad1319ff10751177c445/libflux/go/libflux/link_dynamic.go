//go:build !static_build
// +build !static_build

package libflux

// #cgo pkg-config: flux
import "C"
